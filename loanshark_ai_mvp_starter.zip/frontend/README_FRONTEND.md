# Loanshark.ai Frontend (MVP)

## Quickstart
1) `cp .env.local.example .env.local` and set `NEXT_PUBLIC_API_URL` to your backend URL.
2) Install: `npm install`
3) Run: `npm run dev`
4) Open http://localhost:3000

## Deploy to Vercel
- Push this folder to a GitHub repo.
- Import the repo in Vercel and set Environment Variable `NEXT_PUBLIC_API_URL`.
- Connect your GoDaddy domain inside Vercel > Settings > Domains.
