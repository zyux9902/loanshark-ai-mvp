import { useState } from "react";
import axios from "axios";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Legend } from "recharts";
import "../styles/globals.css";

const COLORS = ["#3b82f6", "#f59e0b"];

export default function Home() {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

  const onUpload = async () => {
    setError("");
    if (!file) {
      setError("Please select a PDF or DOCX file first.");
      return;
    }
    const formData = new FormData();
    formData.append("file", file);
    try {
      setLoading(true);
      const { data } = await axios.post(`${API_URL}/analyze`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setResult(data);
    } catch (e) {
      console.error(e);
      setError("Upload failed. Make sure the backend is running and API URL is correct.");
    } finally {
      setLoading(false);
    }
  };

  const onCheckout = async () => {
    try {
      const { data } = await axios.post(`${API_URL}/create-checkout-session`, {
        features: ["full_report", "download_pdf"]
      });
      if (data?.checkout_url) {
        window.location.href = data.checkout_url;
      }
    } catch (e) {
      console.error(e);
      alert("Stripe checkout failed. Check backend Stripe keys.");
    }
  };

  const costData = result?.cost_breakdown ? [
    { name: "Principal", value: result.cost_breakdown.principal || 0 },
    { name: "Interest", value: result.cost_breakdown.interest || 0 },
  ] : [];

  const schedule = result?.balance_over_time || [];

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white shadow">
        <div className="max-w-5xl mx-auto p-6 flex items-center justify-between">
          <div className="text-2xl font-bold text-sky-600">Loanshark.ai</div>
          <button onClick={onCheckout} className="px-4 py-2 rounded-xl bg-sky-600 text-white hover:bg-sky-700">
            Upgrade for Full Report
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto p-6">
        <div className="bg-white p-6 rounded-2xl shadow mb-6">
          <h1 className="text-2xl font-semibold mb-2">AI Loan Analyzer (MVP)</h1>
          <p className="text-slate-600">Upload your loan contract (PDF or DOCX). Get a simple, clear AI summary.</p>
          <div className="mt-4 flex gap-3 items-center">
            <input type="file" accept=".pdf,.doc,.docx" onChange={(e)=> setFile(e.target.files?.[0] || null)} />
            <button onClick={onUpload} disabled={loading} className="px-4 py-2 rounded-xl bg-slate-900 text-white hover:bg-slate-800 disabled:opacity-50">
              {loading ? "Analyzing..." : "Analyze"}
            </button>
            {error && <span className="text-red-600 text-sm">{error}</span>}
          </div>
        </div>

        {result && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-2xl shadow col-span-1">
              <h2 className="text-xl font-semibold mb-4">Loan Health</h2>
              <div className="text-5xl font-bold">
                {result.health_score}/100
              </div>
              <div className="mt-2 text-sm">
                <span className={`px-2 py-1 rounded ${result.traffic_light === "Green" ? "bg-green-100 text-green-700" : result.traffic_light === "Yellow" ? "bg-yellow-100 text-yellow-700" : "bg-red-100 text-red-700"}`}>
                  {result.traffic_light}
                </span>
              </div>
              <p className="mt-4 text-slate-600">{result.summary}</p>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow col-span-1">
              <h2 className="text-xl font-semibold mb-4">Cost Breakdown</h2>
              <div className="w-full h-64">
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={costData} dataKey="value" outerRadius={90} label>
                      {costData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-2 text-sm text-slate-600">
                Principal: ${result?.cost_breakdown?.principal?.toLocaleString() || 0}<br/>
                Interest: ${result?.cost_breakdown?.interest?.toLocaleString() || 0}<br/>
                Total: ${((result?.cost_breakdown?.principal||0) + (result?.cost_breakdown?.interest||0)).toLocaleString()}
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow col-span-1">
              <h2 className="text-xl font-semibold mb-4">Balance Over Time</h2>
              <div className="w-full h-64">
                <ResponsiveContainer>
                  <LineChart data={schedule}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="balance" dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {result && (
          <div className="bg-white p-6 rounded-2xl shadow mt-6">
            <h2 className="text-xl font-semibold mb-2">Key Terms</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div><span className="text-slate-500">APR</span><div className="font-semibold">{result?.terms?.apr ?? "—"}</div></div>
              <div><span className="text-slate-500">Rate</span><div className="font-semibold">{result?.terms?.rate ?? "—"}</div></div>
              <div><span className="text-slate-500">Term</span><div className="font-semibold">{result?.terms?.term_months ?? "—"} mo</div></div>
              <div><span className="text-slate-500">Payment</span><div className="font-semibold">${result?.terms?.monthly_payment?.toLocaleString?.() ?? "—"}</div></div>
            </div>
          </div>
        )}
      </main>

      <footer className="text-center text-slate-500 text-sm py-6">
        © {new Date().getFullYear()} Loanshark.ai — MVP
      </footer>
    </div>
  );
}
