# Loanshark.ai Backend (MVP)

## Quickstart (Local)
1) `python -m venv .venv && source .venv/bin/activate` (Windows: `.venv\Scripts\activate`)
2) `pip install -r requirements.txt`
3) Copy `.env.example` to `.env` and fill keys.
4) Run: `uvicorn main:app --reload --port 8000`

## Deploy
- Render.com (Free Web Service)
  - Start: `uvicorn main:app --host 0.0.0.0 --port 8000`
  - Add Environment Variables from `.env.example`.

## Notes
- Parses text-based PDFs and DOCX. OCR for scanned PDFs is not included in MVP.
