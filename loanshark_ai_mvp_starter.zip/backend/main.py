import os, io
from typing import List
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from dotenv import load_dotenv

import fitz  # PyMuPDF
from docx import Document
import stripe

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY","")
STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY","")
STRIPE_PRICE_ID = os.getenv("STRIPE_PRICE_ID","")
FRONTEND_URL = os.getenv("FRONTEND_URL","http://localhost:3000")

stripe.api_key = STRIPE_SECRET_KEY
client = OpenAI(api_key=OPENAI_API_KEY) if (OpenAI and OPENAI_API_KEY) else None

app = FastAPI(title="Loanshark.ai MVP API")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def extract_text_from_pdf(file_bytes: bytes) -> str:
    text = ""
    with fitz.open(stream=file_bytes, filetype="pdf") as doc:
        for page in doc:
            text += page.get_text()
    return text

def extract_text_from_docx(file_bytes: bytes) -> str:
    bio = io.BytesIO(file_bytes)
    doc = Document(bio)
    return "\n".join([p.text for p in doc.paragraphs])

def naive_term_guess(text: str):
    import re
    apr = None
    rate = None
    term_months = None
    monthly_payment = None

    apr_match = re.search(r'APR[^0-9]*([0-9]+(\.[0-9]+)?)\s*%', text, re.IGNORECASE)
    if apr_match: apr = float(apr_match.group(1))

    rate_match = re.search(r'interest[^0-9]*rate[^0-9]*([0-9]+(\.[0-9]+)?)\s*%', text, re.IGNORECASE)
    if rate_match: rate = float(rate_match.group(1))

    term_match = re.search(r'(?:term|months?)\D+([0-9]{1,3})\b', text, re.IGNORECASE)
    if term_match: term_months = int(term_match.group(1))

    pay_match = re.search(r'(?:monthly|payment)[^\$]*\$\s*([0-9,]+(\.[0-9]+)?)', text, re.IGNORECASE)
    if pay_match: monthly_payment = float(pay_match.group(1).replace(",",""))

    return {
        "apr": apr if apr is not None else "unknown",
        "rate": rate if rate is not None else (apr if apr is not None else "unknown"),
        "term_months": term_months if term_months is not None else "unknown",
        "monthly_payment": monthly_payment if monthly_payment is not None else "unknown",
    }

def amortization(principal: float, annual_rate_pct: float, months: int):
    if any(v in [None, "unknown"] for v in [principal, annual_rate_pct, months]) or months == 0:
        return [], {"principal": principal or 0, "interest": 0}
    r = (annual_rate_pct/100)/12
    payment = principal / months if r == 0 else principal * (r * (1 + r)**months) / ((1 + r)**months - 1)
    balance = principal
    total_interest = 0.0
    schedule = []
    for m in range(1, months+1):
        interest = balance * r
        principal_paid = payment - interest
        balance = max(0.0, balance - principal_paid)
        total_interest += interest
        schedule.append({"month": m, "balance": round(balance,2)})
    return schedule, {"principal": round(principal,2), "interest": round(total_interest,2)}

def summarize_with_ai(text: str, terms: dict):
    if client:
        prompt = f"""
        Read the following loan text and extracted terms {terms}.
        In 3 sentences max, explain in plain English what this loan will cost overall,
        any risky clauses (prepayment penalty, balloon, fees), and who should consider refinancing.
        Text:
        {text[:6000]}
        """
        try:
            resp = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role":"user","content":prompt}],
                temperature=0.2,
            )
            return resp.choices[0].message.content.strip()
        except Exception:
            return "Summary temporarily unavailable. (AI error)"
    else:
        return "This loan seems average based on the extracted terms. Consider refinancing if APR is >2% above market; avoid prepayment penalties; and keep monthly payment under ~20% of income."

class CheckoutReq(BaseModel):
    features: List[str] = []

@app.post("/create-checkout-session")
def create_checkout_session(req: CheckoutReq):
    if not STRIPE_SECRET_KEY or not STRIPE_PRICE_ID:
        return JSONResponse({"error":"Stripe not configured on server"}, status_code=400)
    try:
        session = stripe.checkout.Session.create(
            mode="payment",
            line_items=[{"price": STRIPE_PRICE_ID, "quantity": 1}],
            success_url=f"{FRONTEND_URL}/?success=true",
            cancel_url=f"{FRONTEND_URL}/?canceled=true",
        )
        return {"checkout_url": session.url}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=400)

@app.post("/analyze")
async def analyze(file: UploadFile = File(...), principal: float = Form(default=25000.0)):
    ext = (file.filename or "").lower()
    blob = await file.read()

    if ext.endswith(".pdf"):
        text = extract_text_from_pdf(blob)
    elif ext.endswith(".docx"):
        text = extract_text_from_docx(blob)
    else:
        return JSONResponse({"error":"Please upload a PDF or DOCX."}, status_code=400)

    terms = naive_term_guess(text)

    apr = terms.get("apr") if isinstance(terms.get("apr"), (int,float)) else 9.5
    months = terms.get("term_months") if isinstance(terms.get("term_months"), int) else 60
    principal_val = principal if isinstance(principal, (int,float)) else 25000.0

    schedule, cost = amortization(principal=principal_val, annual_rate_pct=float(apr), months=int(months))

    traffic = "Green"; score = 85
    if apr >= 10: traffic = "Yellow"; score = 70
    if apr >= 15: traffic = "Red"; score = 50

    summary = summarize_with_ai(text, terms)

    return {
        "summary": summary,
        "health_score": score,
        "traffic_light": traffic,
        "terms": terms,
        "cost_breakdown": cost,
        "balance_over_time": schedule
    }
