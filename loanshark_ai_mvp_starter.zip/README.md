# Loanshark.ai MVP Starter Kit

Includes:
- **frontend/** (Next.js + Tailwind + Recharts)
- **backend/** (FastAPI + PyMuPDF + OpenAI + Stripe)

## Local Run
- Backend: see `backend/README_BACKEND.md`
- Frontend: see `frontend/README_FRONTEND.md`

## Deploy
- Backend -> Render.com (free)
- Frontend -> Vercel (free)
- Connect GoDaddy domain in Vercel Domains settings.

## Env Setup
- Backend: `.env` from `backend/.env.example`
- Frontend: `.env.local` from `frontend/.env.local.example`
